package com.example.demo;

import com.mongodb.client.gridfs.model.GridFSFile;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.gridfs.GridFsResource;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.util.DigestUtils;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

@SpringBootTest
public class FileTests {

    @Resource
    private MongoTemplate mongoTemplate;

    @Resource
    private GridFsTemplate gridFsTemplate;

    String MD5 = "d6d2f0a7afb22cd09aca767d6cbeb0a3";
    String ID = "61c57947baecbe4ea682e744";

    @Test
    void store() throws IOException {
        Path path = Paths.get("HELP.md");
        System.out.println(path);
        File file = path.toFile();
        System.out.println(file.getName());

        Map<String, String> metaData = new HashMap<>();
        metaData.put("tags", "test");

        try (InputStream inputStream = Files.newInputStream(path)) {
            ObjectId id = gridFsTemplate.store(inputStream, "HELP.md", metaData);
            System.out.println(id.toHexString());
        }
    }

    @Test
    void get() throws IOException {
        // 文件索引，files
        GridFSFile gridFSFile = gridFsTemplate.findOne(Query.query(Criteria.where("_id").is(ID)));
        if (gridFSFile == null) {
            System.out.println("not exist...");
        }

        GridFsResource resource = gridFsTemplate.getResource(gridFSFile);
        try (InputStream inputStream = resource.getInputStream()) {
            String md5 = DigestUtils.md5DigestAsHex(inputStream);
            System.out.println(MD5.equals(md5));
        }
    }

    @Test
    void del() {
        gridFsTemplate.delete(Query.query(Criteria.where("_id").is(ID)));
    }
}

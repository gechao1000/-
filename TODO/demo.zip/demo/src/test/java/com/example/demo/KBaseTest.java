package com.example.demo;

import com.kbase.jdbc.ConnectionImpl;
import org.junit.jupiter.api.Test;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class KBaseTest {

    public static final String url = "jdbc:kbase://192.168.80.128/TEST";//指定服务器地址和数据库名称
    public static final String driver = "com.kbase.jdbc.Driver";// 指定连接类型
    public static final String user = "DBOWN";//服务器用户名
    public static final String password = "";//服务器密码

    @Test
    public void test() {
        try {
            Class.forName(driver);
            ConnectionImpl conn = (ConnectionImpl) DriverManager.getConnection(url, user, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from SYS_TEAM");
            while (rs.next()) {
                System.out.println(rs.getString(1));
            }
            rs.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.util.DigestUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class AppTest {

    String MD5 = "d6d2f0a7afb22cd09aca767d6cbeb0a3";

    @Test
    public void chcksum() throws IOException {
        Path path = Paths.get("HELP.md");
        byte[] bytes = Files.readAllBytes(path);
        String sign = DigestUtils.md5DigestAsHex(bytes);
        System.out.println(sign);
        System.out.println(MD5.equals(sign));

        try(InputStream inputStream = Files.newInputStream(path)) {
            String s = DigestUtils.md5DigestAsHex(inputStream);
            System.out.println(s);
            System.out.println(MD5.equals(s));
        }
    }
}

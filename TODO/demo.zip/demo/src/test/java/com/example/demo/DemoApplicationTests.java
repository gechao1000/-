package com.example.demo;

import com.example.demo.conf.KBaseProperties;
import com.example.demo.entity.Customer;
import com.example.demo.entity.CustomerRepo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.util.List;

@SpringBootTest
class DemoApplicationTests {

	@Resource
	private MongoTemplate mongoTemplate;

	@Resource
	private CustomerRepo repo;

	@Resource
	private JdbcTemplate jdbcTemplate;

	@Resource
	private DataSource ds;

	@Resource
	private KBaseProperties kBaseProperties;

	@Test
	public void testProp() {
		System.out.println(kBaseProperties);
	}

	@Test
	void contextLoads() {
		System.out.println(mongoTemplate);
		System.out.println(repo);

		repo.deleteAll();

		repo.save(new Customer("Alice", "Smith"));
		repo.save(new Customer("Bob", "Smith"));

		repo.findAll().forEach(System.out::println);
		System.out.println("--------------------------------");

		System.out.println(repo.findByFirstName("Alice"));
		System.out.println(repo.findByLastName("Smith"));
	}

	@Test
	public void testKBase() {
		System.out.println(jdbcTemplate);
		System.out.println(ds);
		System.out.println(ds == jdbcTemplate.getDataSource());

		List<String> query = jdbcTemplate.query("select * from SYS_TEAM", (rs, i) -> {
			return rs.getString(1);
		});
		System.out.println(query);
	}

}

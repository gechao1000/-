package com.example.demo.conf;

import lombok.Data;

@Data
public class HFS {

    public static final int DEFAULT_PORT = 8810;

    public static final int DEFAULT_APP_ID = 1024;

    public static final String DEFAULT_APP_NAME = "HFMS";

    public static final String DEFAULT_APP_KEY = "f4b871d85cd746021b451487849e3cdf";

    private Integer port;

    private String appId;

    private String appName;

    private String appKey;
}

package com.example.demo.conf;

import lombok.Data;
import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "spring.data.mongodb")
public class KBaseProperties {

    public static final int DEFAULT_PORT = 4567;
    public static final String DEFAULT_URI = "kbase://localhost/TEST";
    public static final String DEFAULT_USERNAME = "DBOWN";

    private String host;

    private Integer port = null;

    private String database;

    private String username;
    private String password;

    private final HFS hfs = new HFS();

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    public String getDatabase() {
        return database;
    }

    public void setDatabase(String database) {
        this.database = database;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public HFS getHfs() {
        return hfs;
    }
}
